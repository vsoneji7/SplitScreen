#include "Modules/ModuleManager.h"

class FRemotePOVModule : public IModuleInterface
{
public:
    virtual void StartupModule() override {}
    virtual void ShutdownModule() override {}
};

IMPLEMENT_MODULE(FRemotePOVModule, RemotePOV)